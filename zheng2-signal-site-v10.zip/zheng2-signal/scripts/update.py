#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日更新：抓行情 → 算兩桶訊號與低檔分數 → 跑滾動 10 年回測 → 寫 data/data.json

只用 Python 標準函式庫。由 .github/workflows/update.yml 每個交易日自動執行，
也可以在本機手動跑：  python3 scripts/update.py

規則
  逆勢桶（資金一半）：平時 0050；加權指數自一年高點回落 20% / 30%
                    → 桶內 60% / 100% 換成 00631L；創一年新高 → 全部換回 0050
                    （原本還有「回落 10% 換 30%」一階，回測顯示沒有效果、只增加交易次數，已拿掉）
  順勢桶（資金一半）：加權指數 > 200 日線 ×1.03 → 全部 00631L；< 200 日線 ×0.97 → 全部現金
  訊號以收盤確認、隔一個交易日調整；訊號沒變時，偏離目標超過 10 個百分點才再平衡。
"""
import datetime as dt
import json
import os
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

# ───────── 規則參數 ─────────
LADDER = [(0.20, 0.60), (0.30, 1.00)]   # (回落門檻, 逆勢桶內 00631L 比例)
HIGH_WIN, MA_N, BUF, BUCKET, DRIFT = 252, 200, 0.03, 0.5, 0.10
# ───────── 回測假設 ─────────
BUY, SELL, RF = 0.000855, 0.000855 + 0.001, 0.01 / 252   # 手續費 6 折、賣出加證交稅 0.1%、現金年息 1%
BT_YEARS = 10
CLEAN_FROM = "2015-09-01"     # Yahoo 的 00631L 在這之前有錯價，回測不使用
DAILY_KEEP = 750
# ───────── 低檔分數（只供參考，不影響兩桶配置） ─────────
# 五項條件成立幾項。門檻來自 2001 年以來 56 個波段低點當天的讀數（見 data/extremes.json 的 score）。
SCORE = [("pull", "距 60 日高點", "<=", -10.0, "%"), ("rsi", "RSI(14)", "<=", 30.0, ""), ("vix", "VIX", ">=", 25.0, ""),
         ("m10", "融資 10 日變化", "<=", -5.0, "%"), ("d60", "距 60 日線", "<=", -8.0, "%")]
SCORE_SIG, SCORE_GAP = 4, 20          # 達 4 項算訊號；前 20 個交易日都沒達到才算新的一次

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
OUT = os.path.join(DATA_DIR, "data.json")
# Yahoo 會對某些 User-Agent 回 429，所以準備幾個輪流試
UAS = ["Mozilla/5.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)", "curl/8.4.0"]


# ───────────────────────────── 抓資料 ─────────────────────────────
def _open(url, ua):
    req = urllib.request.Request(url, headers={"User-Agent": ua})
    try:
        return urllib.request.urlopen(req, timeout=30)
    except urllib.error.URLError as e:
        if isinstance(getattr(e, "reason", None), ssl.SSLError):
            import certifi  # 本機 Mac 的 python.org 版 Python 常缺憑證：pip install certifi
            return urllib.request.urlopen(req, timeout=30, context=ssl.create_default_context(cafile=certifi.where()))
        raise


def fetch(sym, years):
    """回傳 {dates, close, adj, live}。失敗會重試；全部失敗就丟例外（舊的 data.json 會保留）。"""
    p2 = int(time.time()) + 86400
    p1 = p2 - int(years * 365.25 * 86400)
    last = None
    for attempt in range(6):
        host = ("query1", "query2")[attempt % 2]
        url = (f"https://{host}.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
               f"?period1={p1}&period2={p2}&interval=1d&events=div%2Csplit")
        try:
            r = json.load(_open(url, UAS[(attempt // 2) % len(UAS)]))["chart"]["result"][0]
            break
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(3 * (attempt + 1))
    else:
        raise RuntimeError(f"抓不到 {sym}：{last}")
    off = r["meta"].get("gmtoffset", 0)
    q = r["indicators"]["quote"][0]["close"]
    a = (r["indicators"].get("adjclose") or [{}])[0].get("adjclose") or q
    dates, close, adj, ts = [], [], [], []
    for t, c, ac in zip(r["timestamp"], q, a):
        if c is None:
            continue
        dates.append(dt.datetime.fromtimestamp(t + off, dt.timezone.utc).strftime("%Y-%m-%d"))
        close.append(float(c))
        adj.append(float(ac if ac is not None else c))
        ts.append(t)
    per = r["meta"].get("currentTradingPeriod", {}).get("regular", {})
    live = bool(per) and bool(ts) and per.get("start", 0) <= ts[-1] and time.time() < per.get("end", 0)
    now = None
    if live:                                   # 盤中未收盤的那一根不用來算訊號，只留作盤中試算的預設值
        at = r["meta"].get("regularMarketTime") or ts[-1]
        now = {"date": dates[-1], "px": round(close[-1], 2), "at": dt.datetime.fromtimestamp(at, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        dates, close, adj = dates[:-1], close[:-1], adj[:-1]
    if len(dates) < 30:
        raise RuntimeError(f"{sym} 資料筆數異常：{len(dates)}")
    return {"dates": dates, "close": close, "adj": adj, "live": now}


def last_intraday(sym, date):
    """Yahoo 盤中常缺前一個交易日的日線。用小時線補該日最後一筆價格（和正式收盤價可能差一點）。"""
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}?range=5d&interval=1h"
        r = json.load(_open(url, UAS[0]))["chart"]["result"][0]
        off, px = r["meta"].get("gmtoffset", 0), None
        for ts, c in zip(r["timestamp"], r["indicators"]["quote"][0]["close"]):
            if c is not None and dt.datetime.fromtimestamp(ts + off, dt.timezone.utc).strftime("%Y-%m-%d") == date:
                px = float(c)
        return px
    except Exception:  # noqa: BLE001
        return None


# ───────────────────────────── 融資資料（只供參考，不影響訊號） ─────────────────────────────
TWSE = "https://www.twse.com.tw/rwd/zh/marginTrading/"
TWSE_REF = "https://www.twse.com.tw/dashboard/zh/credit/margin.html"


def fetch_json(url, referer=None, tries=2):
    last = None
    for attempt in range(tries):
        try:
            h = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)", "Accept": "application/json"}
            if referer:
                h["Referer"] = referer
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001  證交所會擋太頻繁的請求，回來的可能不是 JSON
            last = e
            time.sleep(5)
    raise RuntimeError(f"{url} 讀取失敗：{last}")


def _iso(d):
    return f"{d[:4]}-{d[4:6]}-{d[6:8]}"


def _load(name, default):
    try:
        with open(os.path.join(DATA_DIR, name), encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa: BLE001
        return default


def _save(name, obj):
    with open(os.path.join(DATA_DIR, name), "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))


def _merge(hist, key, rows):
    """把 rows（dict，含 date）併進以欄位陣列存的歷史，依日期去重排序。"""
    cols = [c for c in hist if c != key] or [c for c in (rows[0] if rows else {}) if c != key]
    by = {d: {c: hist[c][i] for c in cols} for i, d in enumerate(hist.get(key, []))}
    for r in rows:
        by[r[key]] = {c: r[c] for c in cols}
    dates = sorted(by)[-2500:]
    return {key: dates, **{c: [by[d][c] for d in dates] for c in cols}}


def margin_block(fetch_new=True):
    """官方擔保維持率與融資餘額（只供參考）。歷史累積在 data/*_hist.json；抓不到就用已累積的資料。"""
    keep = _load("keep_hist.json", {"date": [], "rate": [], "call": [], "exe": []})
    try:   # 證交所臺股儀表板：全市場擔保維持率、低於 130% 戶數、應處分戶數
        if not fetch_new:
            raise LookupError
        days = 60 if len(keep["date"]) < 30 else 10
        r = fetch_json(TWSE + f"BFIJ3U_TREND?response=json&days={days}", TWSE_REF)
        if r.get("stat") == "OK" and r.get("data"):
            keep = _merge(keep, "date", [{"date": _iso(x["date"]), "rate": x["keepRate"], "call": x["callAccNum"], "exe": x["exeAccNum"]} for x in r["data"]])
            _save("keep_hist.json", keep)
    except LookupError:
        pass
    except Exception as e:  # noqa: BLE001
        print(f"[警告] 擔保維持率沒有更新：{e}", file=sys.stderr)

    bal = _load("margin_hist.json", {"date": [], "amt": []})
    mv = None
    try:   # 證交所：上市融資餘額（仟元）與上市總市值（億元），近 30 個交易日
        if not fetch_new:
            raise LookupError
        time.sleep(3)
        r = fetch_json(TWSE + "MI_MARGN_TREND?response=json", TWSE_REF)
        if r.get("stat") == "OK" and r.get("data"):
            if bal["date"] and _iso(r["data"][0]["date"]) > bal["date"][-1]:
                raise RuntimeError("融資餘額歷史中間有缺口")
            bal = _merge(bal, "date", [{"date": _iso(x["date"]), "amt": round(x["marginAmt"] / 1e5)} for x in r["data"]])
            mv = r["data"][-1]["marketValue"]
            _save("margin_hist.json", bal)
    except LookupError:
        pass
    except Exception as e:  # noqa: BLE001
        print(f"[警告] 融資餘額沒有更新：{e}", file=sys.stderr)

    out = {"keep": {k: v[-750:] for k, v in keep.items()}}
    amt, dates = bal["amt"], bal["date"]
    if len(amt) > 21:
        chg = lambda n: round((amt[-1] / amt[-1 - n] - 1) * 100, 1)  # noqa: E731
        out["bal"] = {"date": dates[-1], "amt": amt[-1], "chg1": chg(1), "chg5": chg(5), "chg20": chg(20)}
        i0 = max(20, len(amt) - 750)
        out["m20"] = {"date": dates[i0:], "v": [round((amt[i] / amt[i - 20] - 1) * 100, 1) for i in range(i0, len(amt))]}
    return out


def official_closes(asof, old):
    """證交所公布的加權指數收盤價（當月每日）。回傳 {日期: 收盤}；抓不到回傳 {}。
    同一個資料日已經核對過就直接沿用，不重複請求。"""
    cache = old.get("official") or {}
    if asof in cache and old.get("asof") == asof and old.get("today", {}).get("confirmed"):
        return cache
    try:
        r = fetch_json(f"https://www.twse.com.tw/rwd/zh/afterTrading/FMTQIK?response=json&date={asof[:4]}{asof[5:7]}01")
        out = {}
        for row in r.get("data") or []:
            y, m, d = row[0].split("/")
            out[f"{int(y) + 1911}-{m}-{d}"] = float(row[4].replace(",", ""))
        return out
    except Exception as e:  # noqa: BLE001
        print(f"[警告] 官方收盤價沒有抓到：{e}", file=sys.stderr)
        return {}


# ───────────────────────────── 低檔分數 ─────────────────────────────
def _hit(op, v, th):
    return v is not None and (v <= th if op == "<=" else v >= th)


def score_block(dates, closes, vix, keep_n):
    """每個交易日收盤時的低檔分數（0–5）。只用當下已知的資料：
    VIX 用美股前一晚收盤、融資餘額用前一個交易日（當天的要晚上才公布）。"""
    bal = _load("margin_hist.json", {"date": [], "amt": []})
    n = len(closes)
    up = dn = None
    rsi = [None] * n                                  # Wilder RSI(14)
    for i in range(1, n):
        ch = closes[i] - closes[i - 1]
        u, d = max(ch, 0.0), max(-ch, 0.0)
        up = u if up is None else up + (u - up) / 14
        dn = d if dn is None else dn + (d - dn) / 14
        rsi[i] = 100.0 if dn == 0 else 100 - 100 / (1 + up / dn)
    vi = bi = -1
    days = []
    for i in range(max(60, n - keep_n), n):
        d = dates[i]
        while vi + 1 < len(vix["dates"]) and vix["dates"][vi + 1] < d:
            vi += 1
        while bi + 1 < len(bal["date"]) and bal["date"][bi + 1] < d:
            bi += 1
        w = closes[i - 59: i + 1]
        v = {"pull": (closes[i] / max(w) - 1) * 100, "rsi": rsi[i], "d60": (closes[i] / (sum(w) / 60) - 1) * 100,
             "vix": vix["close"][vi] if vi >= 0 else None,
             "m10": (bal["amt"][bi] / bal["amt"][bi - 10] - 1) * 100 if bi >= 10 else None}
        days.append({"date": d, "v": v, "n": sum(_hit(op, v[k], th) for k, _, op, th, _ in SCORE),
                     "vix_date": vix["dates"][vi] if vi >= 0 else None, "bal_date": bal["date"][bi] if bi >= 0 else None})
    t, ns = days[-1], [x["n"] for x in days]
    before = ns[-1 - SCORE_GAP:-1]
    since = None
    for x in reversed(days):                         # 目前這一段連續達標是從哪天開始
        if x["n"] < SCORE_SIG:
            break
        since = x["date"]
    # 下一個交易日若收在某個價位時的分數（給網頁盤中試算用）。VIX 與融資用目前抓得到的最新一筆。
    lv = vix["close"][-1] if vix["dates"] else None
    lm = (bal["amt"][-1] / bal["amt"][-11] - 1) * 100 if len(bal["amt"]) > 10 else None
    nxt = {"hi59": round(max(closes[-59:]), 2), "sum59": round(sum(closes[-59:]), 2), "last": closes[-1], "up": up, "dn": dn,
           "vix": lv, "m10": None if lm is None else round(lm, 3),
           "fixed": sum(_hit(op, {"vix": lv, "m10": lm}[k], th) for k, _, op, th, _ in SCORE if k in ("vix", "m10"))}
    block = {"n": t["n"], "sig": SCORE_SIG, "since": since, "vix_date": t["vix_date"], "bal_date": t["bal_date"],
             "new": int(t["n"] >= SCORE_SIG and max(before, default=0) < SCORE_SIG),
             "top": int(t["n"] == len(SCORE) and max(before, default=0) < len(SCORE)),
             "items": [{"k": k, "name": name, "op": op, "th": th, "unit": unit,
                        "v": None if t["v"][k] is None else round(t["v"][k], 1), "hit": int(_hit(op, t["v"][k], th))}
                       for k, name, op, th, unit in SCORE]}
    return block, ns, nxt


# ───────────────────────────── 規則重播 ─────────────────────────────
def replay(dates, closes):
    rows, lvl, on, prev = [], 0, True, None
    for i, c in enumerate(closes):
        hi = max(closes[max(0, i - HIGH_WIN + 1): i + 1])
        dd = c / hi - 1
        ma = sum(closes[i - MA_N + 1: i + 1]) / MA_N if i >= MA_N - 1 else None
        if dd >= 0:
            lvl = 0
        for j, (th, _) in enumerate(LADDER):
            if dd <= -th and j + 1 > lvl:
                lvl = j + 1
        if ma is not None:
            if c > ma * (1 + BUF):
                on = True
            elif c < ma * (1 - BUF):
                on = False
        a_l = LADDER[lvl - 1][1] if lvl else 0.0
        w = (round(BUCKET * a_l + (1 - BUCKET) * (1.0 if on else 0.0), 4), round(BUCKET * (1 - a_l), 4))
        rows.append({"date": dates[i], "close": c, "hi": hi, "dd": dd, "ma": ma, "dist": (c / ma - 1) if ma else None,
                     "lvl": lvl, "on": on, "aL": a_l, "wL": w[0], "w50": w[1], "wC": round(1 - w[0] - w[1], 4),
                     "exp": round(2 * w[0] + w[1], 3), "changed": prev is not None and w != prev})
        prev = w
    return rows


# ───────────────────────────── 回測 ─────────────────────────────
def simulate(r_l, r_1, targets, band=DRIFT):
    """targets[i] = 第 i 天收盤後的目標 (00631L 比例, 0050 比例)；隔一個交易日收盤成交。回傳每日資產。"""
    v_l = v_1 = 0.0
    cash, prev, pend, eq = 1.0, None, None, []
    for i in range(len(r_l)):
        v_l *= 1 + r_l[i]
        v_1 *= 1 + r_1[i]
        cash *= 1 + RF
        tot = v_l + v_1 + cash
        if pend is not None:
            w_l, w_1 = pend
            if prev != pend or abs(v_l / tot - w_l) > band or abs(v_1 / tot - w_1) > band:
                d_l, d_1 = w_l * tot - v_l, w_1 * tot - v_1
                cost = sum((BUY if x > 0 else SELL) * abs(x) for x in (d_l, d_1))
                v_l += d_l
                v_1 += d_1
                cash -= d_l + d_1 + cost
                prev = pend
        eq.append(v_l + v_1 + cash)
        pend = targets[i]
    return eq


def backtest(rows, p50, pl):
    by = {r["date"]: r for r in rows}
    m50, ml = dict(zip(p50["dates"], p50["adj"])), dict(zip(pl["dates"], pl["close"]))
    dates = [d for d in by if d in m50 and d in ml and d >= CLEAN_FROM]
    end = dates[-1]
    if end != rows[-1]["date"]:
        raise RuntimeError(f"ETF 日線缺 {rows[-1]['date']}")
    y, m, d = end.split("-")
    start_target = f"{int(y) - BT_YEARS}-{m}-{d}"
    if dates[0] > start_target:
        raise RuntimeError("ETF 歷史不足 10 年")
    r_l = [0.0] + [ml[b] / ml[a] - 1 for a, b in zip(dates, dates[1:])]
    r_1 = [0.0] + [m50[b] / m50[a] - 1 for a, b in zip(dates, dates[1:])]
    if max(abs(x) for x in r_1) > 0.25 or max(abs(x) for x in r_l) > 0.45:
        raise RuntimeError("ETF 價格出現異常跳動（可能是分割未還原），回測不更新")
    strategies = {
        "s0050": [(0.0, 1.0)] * len(dates),
        "s5050": [(0.5, 0.0)] * len(dates),        # 00631L 50% + 現金 50%，偏離 10 個百分點再平衡
        "sL": [(1.0, 0.0)] * len(dates),
        "ladder": [(by[x]["aL"], 1 - by[x]["aL"]) for x in dates],
        "blend": [(by[x]["wL"], by[x]["w50"]) for x in dates],
    }
    names = {"s0050": "0050 持有", "s5050": "50:50", "sL": "00631L 持有", "ladder": "純逆勢", "blend": "混合"}
    i0 = next(i for i, x in enumerate(dates) if x >= start_target)
    win = dates[i0:]
    yrs = (dt.date.fromisoformat(win[-1]) - dt.date.fromisoformat(win[0])).days / 365.25
    month_idx = [i for i in range(len(win)) if i == len(win) - 1 or win[i][:7] != win[i + 1][:7]]
    year_idx = [i for i in range(len(win)) if i == len(win) - 1 or win[i][:4] != win[i + 1][:4]]
    out = {"start": win[0], "end": win[-1], "months": [win[i][:7] for i in month_idx], "eq": {}, "stats": [],
           "yearly": [{"year": win[i][:4]} for i in year_idx],
           "changes": sum(1 for x in win[1:] if by[x]["changed"])}
    for k, tg in strategies.items():
        eq = simulate(r_l, r_1, tg)[i0:]
        eq = [v / eq[0] for v in eq]
        peak, mdd = 0.0, 0.0
        for v in eq:
            peak = max(peak, v)
            mdd = min(mdd, v / peak - 1)
        prev, yr = 1.0, []
        for j, i in enumerate(year_idx):
            yr.append(eq[i] / prev - 1)
            out["yearly"][j][k] = round(yr[-1] * 100, 1)
            prev = eq[i]
        out["eq"][k] = [round(eq[i], 4) for i in month_idx]
        out["stats"].append({"key": k, "name": names[k], "cagr": round((eq[-1] ** (1 / yrs) - 1) * 100, 1),
                             "mdd": round(mdd * 100, 1), "worst": round(min(yr[1:]) * 100, 0), "final": round(eq[-1], 2)})
    return out


# ───────────────────────────── 通知 ─────────────────────────────
def zone_of(ext, key, v):
    """v 落在哪個極端區（回傳該區設定，沒有則 None）。"""
    hit = None
    for z in (ext.get("ind", {}).get(key, {}).get("zones") or []):
        if v is not None and (v <= z["v"] if z["op"] == "<=" else v >= z["v"]):
            hit = z
    return hit


def notify(data, old, ext):
    """有新事件時把通知的標題與內文寫到 NOTIFY_DIR，交給 workflow 開 Issue。同一件事只通知一次。"""
    data["notified"] = prev = old.get("notified", "")
    out_dir = os.environ.get("NOTIFY_DIR")
    if not out_dir:
        return
    t, asof, md = data["today"], data["asof"], data["asof"][5:].replace("-", "/")
    tgt = f"00631L {t['wL']}% / 0050 {t['w50']}% / 現金 {t['wC']}%"
    late = asof < dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).strftime("%Y-%m-%d")   # 已經隔天還沒核對到
    key, events = f"{asof}|{t['wL']}|{t['w50']}", []
    if t["changed"]:
        if (t.get("confirmed") or late) and prev != key:
            note = "" if t.get("confirmed") else "（未取得官方收盤價核對）"
            events.append((f"更正 {md}：目標改為 {tgt}" if prev.startswith(asof + "|") else f"訊號變更 {md}：{tgt}") + note)
            data["notified"] = key
    elif prev.startswith(asof + "|") and not prev.endswith("|none"):
        events.append(f"更正 {md}：收盤價確認後訊號沒有變更，目標維持 {tgt}")
        data["notified"] = asof + "|none"
    names = {k: v["name"] for k, v in ext.get("ind", {}).items()}
    for k, z in data["zones"].items():
        if z and z != (old.get("zones") or {}).get(k) and "zones" in old:
            events.append(f"{names.get(k, k)} 進入「{z}」：{data['zvals'][k]}")
    sc = data.get("score") or {}
    data["score_noted"] = old.get("score_noted", "")
    skey = f"{asof}|{sc.get('n')}"
    if (sc.get("new") or sc.get("top")) and data["score_noted"] != skey:
        hits = "、".join(f"{x['name']} {x['v']}{x['unit']}" for x in sc["items"] if x["hit"])
        events.append(f"低檔分數 {sc['n']}/{len(sc['items'])}（{md}）：{hits}")
        data["score_noted"] = skey
    flag = os.path.join(DATA_DIR, "notify_enabled.txt")
    if not os.path.exists(flag):
        with open(flag, "w", encoding="utf-8") as f:
            f.write(data["generated"] + "\n")
        events.append("通知已啟用（測試）")
    if not events:
        return
    repo, owner = os.environ.get("GITHUB_REPOSITORY", ""), os.environ.get("GITHUB_REPOSITORY_OWNER", "")
    site = f"https://{owner}.github.io/{repo.split('/')[-1]}/" if repo and owner else ""
    m = data["margin"]
    body = [f"@{owner}" if owner else "", "", *[f"- {e}" for e in events], "",
            "| 項目 | 數值 |", "|---|---|",
            f"| 資料日 | {data['asof']} |", f"| 目標配置 | {tgt}（曝險 {t['exp']:.2f}x） |",
            f"| 加權指數 | {t['close']:,}（{t['chg']:+.2f}%）{'，已用證交所收盤價核對' if t.get('confirmed') else '，尚未核對'} |", f"| 距一年高點 | {t['dd']}% |", f"| 距 200 日線 | {t['dist']:+}% |",
            f"| VIX | {t['vix']} |"]
    if sc:
        body.append(f"| 低檔分數 | {sc['n']}/{len(sc['items'])}（達 {sc['sig']} 項為訊號，只供參考，不影響目標配置） |")
    if m.get("bal"):
        body.append(f"| 融資餘額 20 日變化 | {m['bal']['chg20']:+}%（{m['bal']['date']}） |")
    if m.get("keep", {}).get("rate"):
        body.append(f"| 全市場擔保維持率 | {m['keep']['rate'][-1]}%（{m['keep']['date'][-1]}） |")
    body += ["", site, "", "規則計算結果，不是投資建議。"]
    with open(os.path.join(out_dir, "z2_title.txt"), "w", encoding="utf-8") as f:
        f.write(events[0] + (f" 等 {len(events)} 項" if len(events) > 1 else ""))
    with open(os.path.join(out_dir, "z2_body.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(body))
    print("通知：" + "；".join(events))


# ───────────────────────────── 組裝輸出 ─────────────────────────────
def asof(series, key, d, strict=False):
    """series 在日期 d（strict 時為 d 之前）最後一筆的 (日期, 值)。"""
    best = None
    for x, v in zip(series["dates"], series[key]):
        if x < d or (x == d and not strict):
            best = (x, v)
        else:
            break
    return best


def live_only(old):
    """盤中的輕量更新：只抓三個即時報價，其餘沿用上一次完整更新的結果。回傳是否已處理。
    條件不符（還沒有今天的完整資料、收盤價還沒核對、不在盤中）就回傳 False，改走完整更新。"""
    if not (old.get("asof") and old.get("today", {}).get("confirmed") and "m10" in old.get("next", {}).get("score", {})):
        return False
    try:
        tw = fetch("^TWII", 0.25)
        if not tw["live"] or tw["dates"][-1] != old["asof"]:
            return False
        p50, pl = fetch("0050.TW", 0.25), fetch("00631L.TW", 0.25)
    except Exception as e:  # noqa: BLE001
        print(f"[警告] 盤中報價沒有抓到：{e}", file=sys.stderr)
        return False
    old["live"] = dict(tw["live"], px50=(p50["live"] or {}).get("px"), pxL=(pl["live"] or {}).get("px"))
    old["generated"] = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(old, f, ensure_ascii=False, separators=(",", ":"))
    if os.environ.get("NOTIFY_DIR"):                  # 告訴 workflow 這次只有即時報價，不用提交
        open(os.path.join(os.environ["NOTIFY_DIR"], "z2_live_only"), "w").close()
    print(f"盤中報價 {old['live']['at']}：加權 {old['live']['px']}")
    return True


# ───────────────────────────── 盤中迴圈 ─────────────────────────────
# GitHub 的排程常常延遲或漏跑，所以盤中不靠排程：workflow 的 live 工作只要被啟動一次，
# 就自己每分鐘抓一次報價、把 live.json 推到 live 分支（網頁直接讀那個檔），收盤後再自己觸發一次完整更新。
MIS = "https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=tse_t00.tw|tse_0050.tw|tse_00631L.tw&json=1&delay=0"
TPE = dt.timezone(dt.timedelta(hours=8))
LOOP_SEC, OPEN_MIN, CLOSE_MIN = 60, 9 * 60, 13 * 60 + 34


def _utc():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def quotes_mis():
    """證交所基本市況報導站的即時報價（加權指數約 5 秒一筆）。"""
    r = fetch_json(MIS + f"&_={int(time.time() * 1000)}", "https://mis.twse.com.tw/stock/index.jsp", tries=1)
    by = {m["c"]: m for m in r.get("msgArray") or []}

    def px(m):
        try:
            return round(float(m["z"]), 2)
        except (KeyError, ValueError):               # 個股當下沒有成交時 z 是 "-"，改用最佳買賣價的中間值
            return round((float(m["a"].split("_")[0]) + float(m["b"].split("_")[0])) / 2, 2)

    t = by["t00"]
    at = dt.datetime.strptime(t["d"] + t["t"], "%Y%m%d%H:%M:%S").replace(tzinfo=TPE)
    return {"date": at.strftime("%Y-%m-%d"), "px": px(t), "at": at.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "px50": px(by["0050"]), "pxL": px(by["00631L"]), "src": "twse"}


def quotes_yahoo():
    tw = fetch("^TWII", 0.25)
    if not tw["live"]:
        return None
    return dict(tw["live"], px50=(fetch("0050.TW", 0.25)["live"] or {}).get("px"), pxL=(fetch("00631L.TW", 0.25)["live"] or {}).get("px"), src="yahoo")


def push_live(obj):
    """把 live.json 推到 live 分支（每次都是單一個新 commit，強制覆蓋，不累積歷史）。"""
    root = os.path.abspath(os.path.join(DATA_DIR, ".."))
    who = {"NAME": "github-actions[bot]", "EMAIL": "41898282+github-actions[bot]@users.noreply.github.com"}
    env = dict(os.environ, **{f"GIT_{r}_{k}": v for r in ("AUTHOR", "COMMITTER") for k, v in who.items()})

    def git(*a, text=None):
        return subprocess.run(("git",) + a, cwd=root, env=env, input=text, check=True, capture_output=True, text=True).stdout.strip()

    blob = git("hash-object", "-w", "--stdin", text=json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    tree = git("mktree", text=f"100644 blob {blob}\tlive.json\n")
    git("push", "-f", "-q", "origin", f"{git('commit-tree', tree, '-m', 'live')}:refs/heads/live")


def dispatch():
    """觸發一次新的完整更新（用 workflow_dispatch，不受排程延遲影響）。"""
    if os.environ.get("GITHUB_ACTIONS"):
        subprocess.run(["gh", "workflow", "run", "update.yml", "--ref", "main"], check=False)


def loop():
    now = lambda: dt.datetime.now(TPE)  # noqa: E731
    mins = lambda x: x.hour * 60 + x.minute  # noqa: E731
    old = _load("data.json", {})
    try:
        push_live({"asof": old.get("asof"), "generated": _utc(), "live": None})      # 啟動時先報到一次
    except Exception as e:  # noqa: BLE001
        print(f"[警告] live 分支推不上去：{e}", file=sys.stderr)
    n = now()
    if n.weekday() >= 5 or mins(n) < OPEN_MIN - 60:
        return
    today, was_live, fails = n.strftime("%Y-%m-%d"), False, 0
    while mins(now()) <= CLOSE_MIN:
        if mins(now()) >= OPEN_MIN:
            q = None
            try:
                q = quotes_mis()
            except Exception as e:  # noqa: BLE001
                try:
                    q = quotes_yahoo()
                except Exception as e2:  # noqa: BLE001
                    print(f"[警告] 報價沒有抓到：{e}；{e2}", file=sys.stderr)
            if q and q["date"] == today and q["date"] > old.get("asof", ""):
                try:
                    push_live({"asof": old["asof"], "generated": _utc(), "live": q})
                    was_live, fails = True, 0
                    print(f"{q['at']} 加權 {q['px']}（{q['src']}）", flush=True)
                except Exception as e:  # noqa: BLE001
                    fails += 1
                    print(f"[警告] live.json 沒有推上去：{e}", file=sys.stderr)
            elif not was_live and mins(now()) > OPEN_MIN + 20:
                print("今天沒有開市，結束")
                return
            if fails >= 10:
                return
        time.sleep(LOOP_SEC)
    n = now()
    if was_live:                                     # 剛收盤：等報價源出收盤價，再觸發完整更新
        time.sleep(120)
        return dispatch()
    if mins(n) > 19 * 60 + 30:
        return
    # 收盤後：今天的收盤還沒進來、或還沒用證交所收盤價核對，就隔一陣子再跑一次，直到完成
    done = old.get("asof") == today and old.get("today", {}).get("confirmed")
    if not done:
        try:
            traded = quotes_mis()["date"] == today
        except Exception:  # noqa: BLE001
            traded = old.get("asof") == today
        if traded:
            time.sleep(20 * 60 if old.get("asof") == today else 5 * 60)
            dispatch()


def main():
    if "--loop" in sys.argv:
        return loop()
    if live_only(_load("data.json", {})):
        return
    tw = fetch("^TWII", BT_YEARS + 2.5)
    p50 = fetch("0050.TW", BT_YEARS + 1.6)
    pl = fetch("00631L.TW", BT_YEARS + 1.6)
    vix = fetch("^VIX", 4.5)
    old = _load("data.json", {})
    official = official_closes(tw["dates"][-1], old)
    yahoo_last = tw["close"][-1]
    for i, d in enumerate(tw["dates"]):            # 有官方數字的日子一律用官方收盤價
        if d in official:
            tw["close"][i] = official[d]
    confirmed = tw["dates"][-1] in official
    rows = replay(tw["dates"], tw["close"])
    t = rows[-1]

    levels = []
    for j, (th, a) in enumerate(LADDER):
        if j + 1 > t["lvl"]:
            levels.append({"key": f"drop{int(th * 100)}", "kind": "加碼", "px": round(t["hi"] * (1 - th)),
                           "label": f"回落 {int(th * 100)}%：逆勢桶的 00631L 提高到 {int(a * 100)}%"})
    if t["lvl"] > 0:
        levels.append({"key": "reset", "kind": "換回 0050", "px": round(t["hi"]), "label": "創一年新高：逆勢桶全部換回 0050"})
    if t["on"]:
        levels.append({"key": "exit", "kind": "順勢出場", "px": round(t["ma"] * (1 - BUF)), "label": "跌破 200 日線 3%：順勢桶賣出 00631L 轉現金"})
    else:
        levels.append({"key": "enter", "kind": "順勢進場", "px": round(t["ma"] * (1 + BUF)), "label": "站上 200 日線 3%：順勢桶買進 00631L"})
    for lv in levels:
        lv["gap"] = round((lv["px"] / t["close"] - 1) * 100, 1)
    levels.sort(key=lambda x: -x["px"])

    keep = rows[-DAILY_KEEP:]
    daily = {
        "date": [r["date"] for r in keep], "close": [round(r["close"]) for r in keep], "hi": [round(r["hi"]) for r in keep],
        "dd": [round(r["dd"] * 100, 1) for r in keep], "ma": [round(r["ma"]) for r in keep],
        "dist": [round(r["dist"] * 100, 1) for r in keep], "lvl": [r["lvl"] for r in keep], "on": [int(r["on"]) for r in keep],
        "wL": [round(r["wL"] * 100) for r in keep], "w50": [round(r["w50"] * 100) for r in keep], "wC": [round(r["wC"] * 100) for r in keep],
        "exp": [r["exp"] for r in keep], "changed": [int(r["changed"]) for r in keep],
    }
    vi, vseries = 0, []
    for r in keep:                                   # 每個台股交易日收盤時已知的 VIX（美股前一晚收盤）
        while vi + 1 < len(vix["dates"]) and vix["dates"][vi + 1] < r["date"]:
            vi += 1
        vseries.append(round(vix["close"][vi], 1))
    daily["vix"] = vseries
    v = asof(vix, "close", t["date"], strict=True)      # 台股收盤時已知的美股前一晚收盤
    a50, al = asof(p50, "close", t["date"]), asof(pl, "close", t["date"])
    a_l = round(t["aL"] * 100)
    today = {k: daily[k][-1] for k in daily}
    today.update({"vix": round(v[1], 1), "vix_date": v[0], "px50": round(a50[1], 2), "pxL": round(al[1], 2), "px_date": a50[0],
                  "aL": a_l, "a50": 100 - a_l, "bL": 100 if t["on"] else 0, "bC": 0 if t["on"] else 100})

    def day_chg(series, key, d, strict=False):
        """series 在日期 d（strict 時為 d 之前）最後一筆相對前一筆的漲跌 %。"""
        xs = [v for x, v in zip(series["dates"], series[key]) if x < d or (x == d and not strict)]
        return round((xs[-1] / xs[-2] - 1) * 100, 2) if len(xs) >= 2 else None

    today.update({"confirmed": int(confirmed), "yahoo": round(yahoo_last, 2),
                  "chg": round((rows[-1]["close"] / rows[-2]["close"] - 1) * 100, 2), "vix_chg": day_chg(vix, "close", t["date"], True),
                  "px50_chg": day_chg(p50, "adj", t["date"]), "pxL_chg": day_chg(pl, "close", t["date"])})
    ot = old.get("today", {})
    if a50[0] != t["date"] or al[0] != t["date"]:          # Yahoo 盤中常缺前一個交易日的 ETF 日線
        if old.get("asof") == t["date"] and ot.get("px_date") == t["date"] and not ot.get("px_est"):
            today.update({k: ot[k] for k in ("px50", "pxL", "px_date", "px50_chg", "pxL_chg") if k in ot})   # 沿用先前抓到的正式收盤價
        else:
            e50, el = last_intraday("0050.TW", t["date"]), last_intraday("00631L.TW", t["date"])
            if e50 and el:                                  # 用小時線補，標記為估計值
                today.update({"px50_chg": round((e50 / a50[1] - 1) * 100, 2), "pxL_chg": round((el / al[1] - 1) * 100, 2),
                              "px50": round(e50, 2), "pxL": round(el, 2), "px_date": t["date"], "px_est": 1})

    closes = tw["close"]
    data = {"generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "asof": t["date"],
            "today": today, "levels": levels, "daily": daily, "drift": int(DRIFT * 100),
            "margin": margin_block(fetch_new=tw["live"] is None),
            "live": dict(tw["live"], px50=(p50["live"] or {}).get("px"), pxL=(pl["live"] or {}).get("px")) if tw["live"] else None,
            # 下一個交易日收在某個價位時要怎麼算（給網頁的盤中試算用）
            "next": {"hi251": round(max(closes[-(HIGH_WIN - 1):]), 2), "sum199": round(sum(closes[-(MA_N - 1):]), 2),
                     "lvl": t["lvl"], "on": int(t["on"])},
            "rule": {"ladder": LADDER, "ma": MA_N, "buf": BUF, "bucket": BUCKET},
            "official": {d: v for d, v in official.items() if d[:7] == t["date"][:7]}}
    try:                                             # 低檔分數（要在融資資料更新之後算）
        data["score"], ns, nxt = score_block(tw["dates"], tw["close"], vix, DAILY_KEEP)
        daily["score"] = [None] * (len(daily["date"]) - len(ns)) + ns[-len(daily["date"]):]
        today["score"] = data["score"]["n"]
        data["next"]["score"] = nxt
    except Exception as e:  # noqa: BLE001  分數算不出來不影響每日訊號
        print(f"[警告] 低檔分數沒有算出來：{e}", file=sys.stderr)
    ext = _load("extremes.json", {})
    bal = data["margin"].get("bal") or {}
    data["zvals"] = {"dd": f"{today['dd']}%", "dist": f"{today['dist']:+}%", "vix": f"{today['vix']}", "m20": f"{bal.get('chg20', 0):+}%"}
    zv = {"dd": today["dd"], "dist": today["dist"], "vix": today["vix"], "m20": bal.get("chg20")}
    data["zones"] = {k: (zone_of(ext, k, v) or {}).get("label") for k, v in zv.items()}
    try:
        data["bt"] = backtest(rows, p50, pl)
    except Exception as e:  # noqa: BLE001  回測失敗不影響每日訊號：沿用上一次的回測
        print(f"[警告] 回測沒有更新：{e}", file=sys.stderr)
        if "bt" not in old:
            raise
        data["bt"], data["bt_stale"] = old["bt"], True
    notify(data, old, ext)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    print(f"資料日 {t['date']}：00631L {today['wL']}% / 0050 {today['w50']}% / 現金 {today['wC']}%"
          f"｜回測 {data['bt']['start']} ~ {data['bt']['end']}")


if __name__ == "__main__":
    main()
